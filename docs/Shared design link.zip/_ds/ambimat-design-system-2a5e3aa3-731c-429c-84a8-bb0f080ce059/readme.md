# Ambimat Design System

A brand & UI design system for **Ambimat Electronics** (**Ambimat Technologies Pvt. Ltd.** per the brand doc; the decks also use *"Ambimat Group of Companies"* — see conflict below) and its security product **AmbiSecure**.

**This is the TIER-1 base (Ambimat Group)** — the publish-by-default corporate voice that owns every shared invariant. Above it sits **TIER 2**, the single shared **offering theme** (`offering/`) used by every offering; and **TIER 3**, the individual **offerings** (`offerings/<key>/`, e.g. AmbiSecure) which carry only name, logo and content. **Read [`ARCHITECTURE.md`](ARCHITECTURE.md) first** — it defines the three tiers, the variance allowlist, the entity≠offering axes, the resolved white-canvas decision, and the font/icon status.

## Company / product context

**Ambimat Electronics — Ambimat Group of Companies** is an Indian design-and-manufacturing electronics house, established **1982** (44+ years). It positions itself as *"design and manufacturing under one roof — from concept to box-packaged product,"* covering the full engineering stack in-house: product/architecture design, prototyping, embedded firmware, hardware/PCB design, fabrication & QA, manufacturing/turn-key, packaging, cloud + mobile apps, supply chain and certification (FCC, PTCRB). Snapshot metrics used in collateral: **1982** established · **200+** employees · **240+** projects · **70+** global clients · **20+** industries · **8** core technologies.

The Group markets a family of **"Ambi"-prefixed product lines**, each mapped to an industry:

| Sub-brand | Domain |
|---|---|
| **AmbiSecure** | Security & trusted identity (flagship) |
| **AmbiPay** | Payment, transaction & value-transfer |
| **AmbiSpace** | Aerospace & defence electronics |
| **AmbiSense** | Medical devices |
| **AmbiPower** | Utility / metering |
| **AmbiLogistics** | Logistics track & trace |
| **AmbiCon** | Retail |
| **AmbiAutomation** | Industrial automation (HVAC, BACnet/MODBUS) |

**AmbiSecure** is the security & identity business unit — hardware-rooted trust: FIDO2 authenticators, JavaCard applets, secure elements (EAL6+), PKI, device identity, closed-loop ticketing, the ONE Pass card, BioKey biometrics and an eSIM security platform. Shipping identity systems since 2017. Web: `ambisecure.ambimat.com`, `esim.ambimat.com`, corporate `ambimat.com`.

### Sources provided
- `uploads/Ambimat Presentation/Ambimat Deck.dc.html` — 19+ slide corporate capabilities deck (1920×1080). Corporate voice.
- `uploads/AmbiSecure Presentation/AmbiSecure Deck.dc.html` — 20-slide AmbiSecure product deck (1920×1080). Product voice.
- `uploads/AmbiSecure Deck.html` — standalone export.
- Logos + QR codes in each deck's `assets/`.

No source code, Figma file or component library was provided — the component inventory below is derived from the recurring UI patterns in the two decks. No live website or app code was provided, so no product UI kit is included (see Caveats).

---

## CONTENT FUNDAMENTALS — how the copy is written

- **Voice:** confident, engineering-led, plain-spoken B2B. It sells capability and accountability, not hype. Signature line: *"Concept to box-packaged product."* and *"One accountable team — every discipline in-house."*
- **Person:** mostly **first-person plural / company-as-subject** — "What we do", "we take products from concept to production", "Ambimat combines embedded engineering with…". Rarely addresses "you".
- **Casing:** slide **headings are sentence case** ("Full-stack expertise", "Why Ambimat is different"). **Kickers and labels are UPPERCASE** with wide letter-spacing ("ENGINEERING PRODUCTS & SERVICES", "CORE PHILOSOPHY", "STANDARDS & INTERFACES", "SCAN TO EXPLORE"). Metric labels are UPPERCASE ("PROJECTS EXECUTED").
- **Numbers & specificity:** heavy use of concrete metrics and standards — "44+ years", "240+ projects", and named standards/protocols (FIDO2, EMVCo L1, ISO 14443 A/B, MQTT/HTTPS, ARM Cortex-M). Standards are shown as chips.
- **Structure:** kicker → heading → one-line lead → card grid → a closing red-left-bar callout that restates the takeaway. Section dividers use "SECTION 0X" + a huge title.
- **Punctuation:** em-dashes and mid-dots (·) as separators in kickers and footers. Arrows (→, ›, ↗) for flow and links.
- **Emoji:** **never.** The brand uses line icons and geometric motifs instead.
- **Tone words:** "hardware-rooted", "end-to-end", "secure", "in-house", "field-serviceable", "production-grade".

---

## VISUAL FOUNDATIONS

- **Two voices, one palette.** Both systems share the signature **red `#E3222A`** and the co-primary greys. They differ in type and surface:
  - **Parent (Ambimat Group):** headings **Montserrat** (Bold/SemiBold), body **Source Sans 3**, technical **JetBrains Mono** (per brand doc; ⚠ placeholder Google Fonts). Pure **white** `#FFFFFF` pages, soft-grey surfaces (`#F4F5F6`), dark-grey ink `#3A3F40`, co-primary grey `#616A6C`. *(Note: the brand doc also calls for a dark-grey presentation background — see ARCHITECTURE.md §4.)*
  - **Child (AmbiSecure):** **Space Grotesk** (display, weight 600), **IBM Plex Sans** (body), **IBM Plex Mono** (labels). Warm **paper** `#fdfcfa`, deep ink `#16181c`, warm hairlines, sharp (0-radius) corners. Overrides only — everything else inherited.
- **Color vibe:** high-contrast, mostly monochrome + one hot red accent. No secondary hues. Imagery is minimal; motifs are geometric line-art, not photography. When photos appear they are cool/neutral.
- **Backgrounds:** flat solid (white or warm paper). Occasional faint **blueprint grid** (1px lines at ~40–56px, opacity ~0.045), sometimes masked with a radial fade. **No gradients** as decoration. **No textures** beyond the grid.
- **Signature motifs (use these to make anything feel on-brand):**
  1. **Red corner triangle** bottom-right (`clip-path:polygon(100% 0,100% 100%,0 100%)`), ~130–560px.
  2. **Short red accent bar** — 48×4px rule under a kicker / above a heading.
  3. **Red left-bar callout strip** — full-width `#F4F5F6` panel with a 4px red left border to close a slide.
  4. **Red top-bar feature cards** — surface card with a 4px red top border.
  5. **Concentric target** — nested squares (product) or circles (corporate) with a solid red center dot; a technical "root of trust" emblem.
  6. **Footer rule + lockup** — hairline + "Ambimat Group of Companies | www.ambimat.com".
- **Cards:** flat fill `#F4F5F6` (corporate) / white with warm border (product). Radius **12–14px** corporate, **0px** product. Border is a hairline `#E6E7E9`/`#d9d6cf`; the red accent (top/left bar) does the emphasizing, **not shadow**.
- **Shadows:** essentially none. The only shadow in-source is a 2px red ring around process-timeline node dots. Depth comes from borders and the red accents. (Tokens include a subtle optional `--shadow-card`/`--shadow-pop` for interactive UI, used sparingly.)
- **Borders / hairlines:** 1px, cool `#E6E7E9`/`#E0E0E0` or warm `#e4e3df`/`#d9d6cf`. Red rules are 2–4px.
- **Corner radii:** small elements (tags, buttons) 6–8px; cards 12–14px; product surfaces 0px; circles for step badges and icon dots.
- **Icons:** thin (2px) single-stroke line icons on a rounded white tile, occasionally with one stroke recolored red. Chips carry standards/protocol names.
- **Layout:** deck grid **1920×1080**; side margin **100px** corporate / **140px** product. Card grids use **~24–26px** gaps. Fixed footer at the bottom; logo top-left; kicker/page-number top row (product).
- **Transparency / blur:** rare — only the faint grid overlay uses opacity; no glass/blur effects.
- **Animation:** decks are static (deck-stage handles slide transitions). For UI: short (120–180ms) ease transitions, **no bounce**. Hover = slightly darker/lighter fill; press = darker (`--red-700`). Keep motion restrained.

---

## ICONOGRAPHY

- **Icons are a single, parent-owned layer.** Every icon renders through the **`Icon` component** (`components/icon/Icon.jsx`), driven by `tokens/base/icons.css`. Never inline a raw `<svg>` in a component or slide — routing through `<Icon>` makes swapping the real set a one-place change. The child inherits this layer.
- **⚠ PLACEHOLDER — PENDING REPLACEMENT.** The rendered glyphs are a **Lucide-style line stand-in**; the real enterprise set is incoming from the brand owner. Do **not** design around Lucide specifics.
- **Contract** (what the real set must satisfy): 24px canonical (26/28/30/34 also used), 2px single stroke, round caps/joins, **outline** style, one path may take the red accent, optically centred in a rounded white tile. Named icons and the child-only security extension are listed in `ARCHITECTURE.md` §6.
- **Source style:** the decks drew icons as inline SVG line icons (2px, round, `#3A3F40` with one path in `#E3222A`) on a rounded white tile — the stand-in follows this spirit.
- **Emoji:** never used. **Unicode glyphs** as micro-icons: `✓` (red checks), `›`/`→` (flow), `↗` (external links), `·` (separators).
- Real raster assets in `assets/`: `ambimat-logo.png`, `ambisecure-logo.png`, product QR codes, facility image.

---

## Index / manifest

**Root**
- `styles.css` — PARENT global entry (imports fonts + `tokens/base/*`). Consumers attach this.
- `ARCHITECTURE.md` — parent/child model, inheritance tables, diffs, placeholders (read first).
- `tokens/fonts.css` — parent webfonts (⚠ placeholder). `tokens/base/` — `palette.css`, `type.css`, `layout.css`, `effects.css`, `icons.css`, `semantics.css` (the shared base layer).
- `assets/` — `ambimat-logo.png`, `ambisecure-logo.png`, `qr-ambisecure.png`, `qr-esim.png`, `qr-ambipower.png`, `qr-ambiautomation.png`, `qr-ambimat.png`, `ambimat-facility.png` (shared; child references these).
- `thumbnail.html` — homepage tile. `SKILL.md` — Agent-Skills entry point.

**Components** (`window.AmbimatDesignSystem_2a5e3a`) — theme-driven, re-theme automatically under the offering tier.
- `components/brand/` — **Logo** (real dark/white logo suite), **Surface** (tonal context for dark accents), **ContactBlock** (entity legal/contact lockup; fails loudly on missing data).
- `components/icon/` — **Icon** (shared UI glyph layer; 22 in-house glyphs, ORIGINATED not supplied).
- `components/dataviz/` — **Chart** (bar/line/stacked; grey series + single red highlight).
- `components/content/` — **StatCard**, **FeatureCard**, **Callout**, **ProcessStep**, **QRBlock**, **SlideHeading**, **Table** (mono header rule; red highlight column; numeric-right).
- `components/actions/` — **Button**, **Tag**, **Badge**.

**Fonts:** self-hosted woff2 in `fonts/` (OFL, offline-safe) — `fonts/LICENSES.md`. **Entity data:** `entities.json` (fill before publishing).

**Foundation cards** (`guidelines/`) — Colors, Type (Ambimat Group voice, Display scale), Spacing, Brand (Logos, Signature motifs, Sub-brand family).

**Slides** (`slides/`) — Corporate cover, Metric snapshot, Capabilities grid, Section break; **`slides/archetypes/`** — Agenda, One-big-statement, Two-column, Full-bleed image, Chart, Table, Quote, Closing/CTA (the 11 archetypes, tier-1 structure — ARCHITECTURE.md §13).

**Subsystems** (all tier 1 — ARCHITECTURE.md §10–§14): **imagery** (`tokens/base/imagery.css` + AI-image scaffold in SKILL.md), **data-viz** (`tokens/base/dataviz.css` + `Chart`), **rulebook** (colour pairings/contrast, type limits, layout, voice). Cards: Pairings & contrast, Data-viz palette, Imagery treatment.

**Templates** (`templates/`) — `deck/` (corporate tier-1 deck), `offering-deck/` (shared offering tier-2 deck; prompts for entity + offering).

**Tiers 2 & 3** — `offering/` (shared offering theme: `styles.css`, `tokens/`, `guidelines/`), `offerings/<key>/` (individual offerings: `ambisecure/`, plus the near-empty `offering-template/`). See `ARCHITECTURE.md` and `offerings/offering-template/readme.md`.

---

## Caveats
- **Parent/child in one project:** this project compiles the **parent** only; AmbiSecure lives under `ambisecure/` and is not yet a separately-attachable compiled system. To split it out, see `ARCHITECTURE.md` §0/§7.
- **Fonts are ⚠ PLACEHOLDERS** (Google Fonts): parent Montserrat/Source Sans 3/JetBrains Mono; child Space Grotesk/IBM Plex Sans/IBM Plex Mono. Send licensed binaries to self-host — token names won't change. See `ARCHITECTURE.md` §5.
- **Icons are ⚠ PLACEHOLDERS** (Lucide stand-in) behind the parent `<Icon>` layer, pending the real enterprise set. See `ARCHITECTURE.md` §6.
- **Company-name conflict:** brand doc says *"Ambimat Technologies Pvt. Ltd."*; decks say *"Ambimat Group of Companies"*. Default (`--footer-entity`) follows the doc — flip the token if needed.
- **Presentation background:** the brand doc calls for a **dark-grey** presentation background; current slides are white/paper. Your call — see `ARCHITECTURE.md` §4.
- **No product UI kit** (only decks provided). See `ARCHITECTURE.md` §8 for what's needed and the parent/child-strain risk.
